package com.example.demo;

public class MessageServiceImpl implements MessageService {
    public String getMessage() {
        return "Hello from Spring Core!";
    }
}