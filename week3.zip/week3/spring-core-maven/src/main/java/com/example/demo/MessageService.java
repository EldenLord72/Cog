package com.example.demo;

public interface MessageService {
    String getMessage();
}